This directory is for all Ext JS user extensions that have been found on the
web but NOT distributed with the default Ext JS UX distribution. Each
contribution should have it's source clearly listed in the comments.
