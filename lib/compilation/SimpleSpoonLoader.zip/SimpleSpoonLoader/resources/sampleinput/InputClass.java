package sampleinput;

import sample.IHello;

public class InputClass implements IHello {
	public void hello() {
		System.out.println("hello");
	}
}
