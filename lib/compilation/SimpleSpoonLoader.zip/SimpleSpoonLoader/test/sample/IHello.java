package sample;

public interface IHello {
	public void hello();
}
