package sample;

import java.lang.reflect.Method;
import java.util.List;

import spoon.reflect.Factory;
import spoon.reflect.code.CtStatement;
import spoon.reflect.declaration.CtExecutable;
import spoon.reflect.declaration.CtSimpleType;
import spoonloader.SimpleSpoonLoader;

public class Main {

	public static void main(String[] args) throws Exception {
		SimpleSpoonLoader loader = new SimpleSpoonLoader();
		loader.addSourcePath("resources/sampleinput");
		
		// Execute original class
		Class<IHello> inputClass = loader.load("sampleinput.InputClass");
		printCode(loader.mirror(inputClass));
		execute(inputClass);
		
		// Modify class
		modify(inputClass, "System.out.println(\"goodbye\")", loader.getFactory());
		loader.compile();
		
		// Execute modified class
		Class<IHello> modifiedClass = loader.load("sampleinput.InputClass");
		printCode(loader.mirror(modifiedClass));
		execute(modifiedClass);
	}

	/**
	 * Run {@link IHello#hello()} on an instance of the given class
	 */
	private static void execute(Class<IHello> inputClass) throws Exception {
		IHello instance = inputClass.newInstance();
		instance.hello();
	}
	
	/**
	 * Modify {@link IHello#hello()} to include the given statement
	 */
	private static void modify(
			Class<IHello> inputClass, 
			String newStatementString, 
			Factory factory) throws Exception {		
		CtStatement newStatement = 
			factory.Code().createCodeSnippetStatement(newStatementString);
		Method method = inputClass.getMethod("hello");
		CtExecutable<?> methodDecl = 
			factory.Method().createReference(method).getDeclaration();			
		List<CtStatement> statements = methodDecl.getBody().getStatements();	
		statements.clear();
		statements.add(newStatement);
	}

	/**
	 * Print the source code of the given type
	 */
	private static void printCode(CtSimpleType<IHello> ctSimpleType) {
		System.out.println(ctSimpleType);
	}
}
