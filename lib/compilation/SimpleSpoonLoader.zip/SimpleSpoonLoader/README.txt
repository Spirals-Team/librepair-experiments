To compile, run:
  
  ant
  
To run the sample in test/sample/Main.java, run:

  ant run-sample

See comments in the spoonloader.SimpleSpoonLoader class for usage.

Spoon <http://spoon.gforge.inria.fr/> is used under a CeCILL license 
<http://www.cecill.info/index.en.html>. All other code is released to the 
public domain. 