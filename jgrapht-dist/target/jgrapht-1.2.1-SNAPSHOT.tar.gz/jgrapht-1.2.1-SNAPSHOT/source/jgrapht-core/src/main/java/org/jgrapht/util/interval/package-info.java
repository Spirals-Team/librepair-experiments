/**
 * Data structures for interval graphs.
 */
package org.jgrapht.util.interval;
