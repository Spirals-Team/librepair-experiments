
/**
 * Interval graph related algorithms.
 *
 */
package org.jgrapht.alg.intervalgraph;
