/**
 * Utilities used by JGraphT algorithms.
 */
package org.jgrapht.alg.util;
