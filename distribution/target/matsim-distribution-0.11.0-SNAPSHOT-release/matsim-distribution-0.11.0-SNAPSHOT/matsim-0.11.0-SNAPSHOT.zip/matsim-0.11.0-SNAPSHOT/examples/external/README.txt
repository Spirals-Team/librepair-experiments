This directory contains files that are used by the "Getting Started" tutorial.
